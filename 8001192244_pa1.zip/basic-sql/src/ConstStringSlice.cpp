#include "ConstStringSlice.h"

namespace basic_sql {
ConstStringSlice::ConstStringSlice() : ptr(nullptr), len(0) {}
ConstStringSlice::ConstStringSlice(const char *c_str)
    : ptr(c_str), len(strlen(c_str)) {}
ConstStringSlice::ConstStringSlice(const char *ptr, size_t len)
    : ptr(ptr), len(len) {}

bool ConstStringSlice::is_empty() const { return this->len == 0; }

size_t ConstStringSlice::size() const { return this->len; }

bool ConstStringSlice::case_insensitive_compare(const char *other) const {
  for (size_t i = 0; i < this->len; i++)
    if (other[i] == 0 || (std::toupper((*this)[i]) != std::toupper(other[i])))
      return false;

  return true;
}

bool ConstStringSlice::starts_with(ConstStringSlice slice) {
  if (slice.size() > this->size())
    return false;

  // We know that slice is smaller than this now.
  // Just comapre the front of this string and the entire other one.
  for (size_t i = 0; i < slice.size(); i++) {
    if (this->ptr[i] != slice[i])
      return false;
  }

  return true;
}

const char &ConstStringSlice::operator[](size_t i) const {
  assert(i < this->len);
  return this->ptr[i];
}

std::ostream &operator<<(std::ostream &os, const ConstStringSlice &t) {
  for (size_t i = 0; i < t.size(); i++)
    os << t[i];

  return os;
}

bool operator==(const ConstStringSlice &lhs, const ConstStringSlice &rhs) {
  size_t lhs_size = lhs.size();
  if (lhs_size != rhs.size())
    return false;

  for (size_t i = 0; i < lhs_size; i++)
    if (lhs[i] != rhs[i])
      return false;

  return true;
}
} // namespace basic_sql