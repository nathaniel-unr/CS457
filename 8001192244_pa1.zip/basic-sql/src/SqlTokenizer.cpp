#include "SqlTokenizer.h"

namespace basic_sql {
namespace tokenizer {
std::ostream &operator<<(std::ostream &os, const SqlKeyword &t) {
  switch (t) {
  case SqlKeyword::CREATE:
    os << "CREATE";
    break;
  case SqlKeyword::DATABASE:
    os << "DATABASE";
    break;
  case SqlKeyword::DROP:
    os << "DROP";
    break;
  case SqlKeyword::USE:
    os << "USE";
    break;
  case SqlKeyword::TABLE:
    os << "TABLE";
    break;
  case SqlKeyword::SELECT:
    os << "SELECT";
    break;
  case SqlKeyword::FROM:
    os << "FROM";
    break;
  case SqlKeyword::ALTER:
    os << "ALTER";
    break;
  case SqlKeyword::ADD:
    os << "ADD";
    break;
  }

  return os;
}

std::ostream &operator<<(std::ostream &os, const SqlTokenType &t) {
  switch (t) {
  case SqlTokenType::KEYWORD:
    os << "KEYWORD";
    break;
  case SqlTokenType::IDENTIFIER:
    os << "IDENTIFIER";
    break;
  case SqlTokenType::SEMICOLON:
    os << "SEMICOLON";
    break;
  case SqlTokenType::LEFT_PARENTHESIS:
    os << "LEFT_PARENTHESIS";
    break;
  case SqlTokenType::RIGHT_PARENTHESIS:
    os << "RIGHT_PARENTHESIS";
    break;
  case SqlTokenType::COMMA:
    os << "COMMA";
    break;
  case SqlTokenType::INTEGER:
    os << "INTEGER";
    break;
  case SqlTokenType::TYPE:
    os << "TYPE";
    break;
  case SqlTokenType::ASTERISK:
    os << "ASTERISK";
    break;
  }

  return os;
}

bool operator==(const SqlIdentifier &lhs, const SqlIdentifier &rhs) {
  return lhs.slice == rhs.slice;
}

std::ostream &operator<<(std::ostream &os, const SqlIdentifier &t) {
  return (os << t.slice);
}

bool operator==(const SqlInteger &lhs, const SqlInteger &rhs) {
  return lhs.number == rhs.number;
}

std::ostream &operator<<(std::ostream &os, const SqlInteger &t) {
  return (os << t.number);
}

std::ostream &operator<<(std::ostream &os, const SqlType &t) {
  switch (t) {
  case SqlType::INT:
    os << "INT";
    break;
  case SqlType::VARCHAR:
    os << "VARCHAR";
    break;
  case SqlType::FLOAT:
    os << "FLOAT";
    break;
  case SqlType::CHAR:
    os << "CHAR";
    break;
  }

  return os;
}

SqlToken::SqlToken(SqlKeyword keyword)
    : m_token_type(SqlTokenType::KEYWORD), m_keyword(keyword) {}
SqlToken::SqlToken(SqlIdentifier identifier)
    : m_token_type(SqlTokenType::IDENTIFIER), m_identifier(identifier) {}
SqlToken::SqlToken(SqlInteger integer)
    : m_token_type(SqlTokenType::INTEGER), m_integer(integer) {}
SqlToken::SqlToken(SqlType type)
    : m_token_type(SqlTokenType::TYPE), m_type(type) {}

SqlToken SqlToken::semicolon() { return SqlToken(SqlTokenType::SEMICOLON); }
SqlToken SqlToken::left_parenthesis() {
  return SqlToken(SqlTokenType::LEFT_PARENTHESIS);
}
SqlToken SqlToken::right_parenthesis() {
  return SqlToken(SqlTokenType::RIGHT_PARENTHESIS);
}
SqlToken SqlToken::comma() { return SqlToken(SqlTokenType::COMMA); }
SqlToken SqlToken::asterisk() { return SqlToken(SqlTokenType::ASTERISK); }
bool SqlToken::is_keyword() const {
  return this->m_token_type == SqlTokenType::KEYWORD;
}
bool SqlToken::is_identifier() const {
  return this->m_token_type == SqlTokenType::IDENTIFIER;
}
bool SqlToken::is_integer() const {
  return this->m_token_type == SqlTokenType::INTEGER;
}
bool SqlToken::is_type() const {
  return this->m_token_type == SqlTokenType::TYPE;
}
const SqlKeyword &SqlToken::keyword() const {
  assert(this->is_keyword());
  return this->m_keyword;
}

const SqlIdentifier &SqlToken::identifier() const {
  assert(this->is_identifier());
  return this->m_identifier;
}
const SqlInteger &SqlToken::integer() const {
  assert(this->is_integer());
  return this->m_integer;
}
const SqlType &SqlToken::type() const {
  assert(this->is_type());
  return this->m_type;
}
SqlTokenType SqlToken::token_type() const { return this->m_token_type; }
SqlToken::SqlToken(SqlTokenType type) : m_token_type(type) {}

std::ostream &operator<<(std::ostream &os, const SqlToken &t) {
  switch (t.token_type()) {
  case SqlTokenType::KEYWORD:
    os << SqlTokenType::KEYWORD << "(" << t.keyword() << ")";
    break;
  case SqlTokenType::IDENTIFIER:
    os << SqlTokenType::IDENTIFIER << "(" << t.identifier() << ")";
    break;
  case SqlTokenType::SEMICOLON:
    os << SqlTokenType::SEMICOLON;
    break;
  case SqlTokenType::LEFT_PARENTHESIS:
    os << SqlTokenType::LEFT_PARENTHESIS;
    break;
  case SqlTokenType::RIGHT_PARENTHESIS:
    os << SqlTokenType::RIGHT_PARENTHESIS;
    break;
  case SqlTokenType::COMMA:
    os << SqlTokenType::COMMA;
    break;
  case SqlTokenType::INTEGER:
    os << SqlTokenType::INTEGER << "(" << t.integer() << ")";
    break;
  case SqlTokenType::TYPE:
    os << SqlTokenType::TYPE << "(" << t.type() << ")";
    break;
  case SqlTokenType::ASTERISK:
    os << SqlTokenType::ASTERISK;
    break;
  }
  return os;
}

bool operator==(const SqlToken &lhs, const SqlToken &rhs) {
  SqlTokenType lhs_type = lhs.token_type();
  if (lhs_type != rhs.token_type())
    return false;

  // We check above to see that they are the same type.
  // Then, we can safely match and compare their values.
  switch (lhs_type) {
  case SqlTokenType::KEYWORD:
    return lhs.keyword() == rhs.keyword();
  case SqlTokenType::IDENTIFIER:
    return lhs.identifier() == rhs.identifier();
  case SqlTokenType::SEMICOLON:
    return true;
  case SqlTokenType::LEFT_PARENTHESIS:
    return true;
  case SqlTokenType::RIGHT_PARENTHESIS:
    return true;
  case SqlTokenType::COMMA:
    return true;
  case SqlTokenType::INTEGER:
    return lhs.integer() == rhs.integer();
  case SqlTokenType::TYPE:
    return lhs.type() == rhs.type();
  case SqlTokenType::ASTERISK:
    return true;
  default:
    return false;
  }
}

bool operator!=(const SqlToken &lhs, const SqlToken &rhs) {
  return !(lhs == rhs);
}

SqlTokenizer::SqlTokenizer(const std::string &input)
    : input(input), position(0) {}
SqlTokenizerError SqlTokenizer::tokenize(std::vector<SqlToken> &tokens) {
  const char *start_char = this->peek();
  while (start_char) {
    if (isalpha(*start_char)) {
      this->read();

      const char *c = this->peek();
      size_t len = 1;
      while (c && (isalnum(*c) || *c == '_')) {
        this->read();
        c = this->peek();
        len += 1;
      }

      ConstStringSlice slice(start_char, len);

      if (slice.case_insensitive_compare("CREATE")) {
        tokens.push_back(SqlToken(SqlKeyword::CREATE));
      } else if (slice.case_insensitive_compare("DATABASE")) {
        tokens.push_back(SqlToken(SqlKeyword::DATABASE));
      } else if (slice.case_insensitive_compare("DROP")) {
        tokens.push_back(SqlToken(SqlKeyword::DROP));
      } else if (slice.case_insensitive_compare("USE")) {
        tokens.push_back(SqlToken(SqlKeyword::USE));
      } else if (slice.case_insensitive_compare("TABLE")) {
        tokens.push_back(SqlToken(SqlKeyword::TABLE));
      } else if (slice.case_insensitive_compare("SELECT")) {
        tokens.push_back(SqlToken(SqlKeyword::SELECT));
      } else if (slice.case_insensitive_compare("FROM")) {
        tokens.push_back(SqlToken(SqlKeyword::FROM));
      } else if (slice.case_insensitive_compare("ALTER")) {
        tokens.push_back(SqlToken(SqlKeyword::ALTER));
      } else if (slice.case_insensitive_compare("ADD")) {
        tokens.push_back(SqlToken(SqlKeyword::ADD));
      } else if (slice.case_insensitive_compare("INT")) {
        tokens.push_back(SqlToken(SqlType::INT));
      } else if (slice.case_insensitive_compare("VARCHAR")) {
        tokens.push_back(SqlToken(SqlType::VARCHAR));
      } else if (slice.case_insensitive_compare("FLOAT")) {
        tokens.push_back(SqlToken(SqlType::FLOAT));
      } else if (slice.case_insensitive_compare("CHAR")) {
        tokens.push_back(SqlToken(SqlType::CHAR));
      } else {
        tokens.push_back(SqlToken(SqlIdentifier{slice}));
      }
    } else if (isdigit(*start_char)) {
      this->read();
      const char *c = this->peek();
      // already read 1 char
      size_t len = 1;
      while (c && isdigit(*c)) {
        this->read();
        c = this->peek();
        len += 1;
      }

      ConstStringSlice slice(start_char, len);

      // TODO: Better limit tests
      size_t slice_size = slice.size();
      if (slice_size > 6) {
        return SqlTokenizerError{
          last_char : start_char,
          position : this->position,
          error_message : "Number too large",
        };
      }

      int number = 0;
      for (size_t i = 0; i < slice_size; i++) {
        number = (number * 10) + (slice[i] - '0');
      }
      tokens.push_back(SqlToken(SqlInteger{number}));
    } else if (*start_char == ' ') {
      this->read();
    } else if (*start_char == ';') {
      this->read();
      tokens.push_back(SqlToken::semicolon());
    } else if (*start_char == '(') {
      this->read();
      tokens.push_back(SqlToken::left_parenthesis());
    } else if (*start_char == ')') {
      this->read();
      tokens.push_back(SqlToken::right_parenthesis());
    } else if (*start_char == ',') {
      this->read();
      tokens.push_back(SqlToken::comma());
    } else if (*start_char == '*') {
      this->read();
      tokens.push_back(SqlToken::asterisk());
    } else {
      return SqlTokenizerError{
        last_char : start_char,
        position : this->position,
        error_message : "Unexpected char type",
      };
    }

    start_char = this->peek();
  }

  return SqlTokenizerError{
    last_char : start_char,
    position : this->position,
    error_message : SQL_TOKENIZER_OK_MESSAGE,
  };
}

const char *SqlTokenizer::peek() {
  if (this->is_finished())
    return nullptr;
  return &this->input.at(this->position);
}
const char *SqlTokenizer::read() {
  const char *c = this->peek();
  if (c != nullptr)
    this->position += 1;
  return c;
}
} // namespace tokenizer
} // namespace basic_sql