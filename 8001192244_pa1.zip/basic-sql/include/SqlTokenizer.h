#ifndef _SQL_TOKENIZER_H_
#define _SQL_TOKENIZER_H_
#include "ConstStringSlice.h"
#include <ostream>
#include <vector>

namespace basic_sql {
namespace tokenizer {
enum class SqlKeyword {
  CREATE,
  DATABASE,
  DROP,
  USE,
  TABLE,
  SELECT,
  FROM,
  ALTER,
  ADD,
};

std::ostream &operator<<(std::ostream &os, const SqlKeyword &t);

enum class SqlTokenType {
  KEYWORD,
  IDENTIFIER,
  SEMICOLON,
  LEFT_PARENTHESIS,
  RIGHT_PARENTHESIS,
  COMMA,
  INTEGER,
  TYPE,
  ASTERISK,
};

std::ostream &operator<<(std::ostream &os, const SqlTokenType &t);

struct SqlIdentifier {
  ConstStringSlice slice;
};

bool operator==(const SqlIdentifier &lhs, const SqlIdentifier &rhs);
std::ostream &operator<<(std::ostream &os, const SqlIdentifier &t);

struct SqlInteger {
  int number;
};

bool operator==(const SqlInteger &lhs, const SqlInteger &rhs);
std::ostream &operator<<(std::ostream &os, const SqlInteger &t);

enum class SqlType {
  INT,
  VARCHAR,
  FLOAT,
  CHAR,
};

std::ostream &operator<<(std::ostream &os, const SqlType &t);

class SqlToken {
public:
  SqlToken(SqlKeyword keyword);
  SqlToken(SqlIdentifier identifier);
  SqlToken(SqlInteger integer);
  SqlToken(SqlType type);
  static SqlToken semicolon();
  static SqlToken left_parenthesis();
  static SqlToken right_parenthesis();
  static SqlToken comma();
  static SqlToken asterisk();

  /// Returns true if this token is a keyword.
  bool is_keyword() const;

  /// Returns true if this token is an identifier.
  bool is_identifier() const;

  /// Returns true if this token is an identifier.
  bool is_integer() const;

  /// Returns true if this token is a type.
  bool is_type() const;

  /// Get the keyword
  /// This token must be a keyword.
  const SqlKeyword &keyword() const;

  /// Get the identifier
  /// This token must be an identifier.
  const SqlIdentifier &identifier() const;

  /// Get the integer
  /// This token must be an integer.
  const SqlInteger &integer() const;

  /// Get the type
  /// This token must be a type.
  const SqlType &type() const;

  /// Get the type of the token.
  SqlTokenType token_type() const;

private:
  SqlToken(SqlTokenType type);

  SqlTokenType m_token_type;
  union {
    SqlKeyword m_keyword;
    SqlIdentifier m_identifier;
    SqlInteger m_integer;
    SqlType m_type;
  };
};

std::ostream &operator<<(std::ostream &os, const SqlToken &t);
bool operator==(const SqlToken &lhs, const SqlToken &rhs);
bool operator!=(const SqlToken &lhs, const SqlToken &rhs);

static const char *SQL_TOKENIZER_OK_MESSAGE = "OK";

// TODO: Improve error / add error kinds
struct SqlTokenizerError {
  const char *last_char;
  size_t position;
  const char *error_message;

  bool is_ok() {
    return strcmp(this->error_message, SQL_TOKENIZER_OK_MESSAGE) == 0;
  }
};

class SqlTokenizer {
public:
  /// Make a new tokeniser over a string
  SqlTokenizer(const std::string &input);

  /// Tokenize
  SqlTokenizerError tokenize(std::vector<SqlToken> &tokens);

protected:
private:
  const std::string &input;
  size_t position;

  /// Returns true if the entire string has been read.
  bool is_finished() { return position >= input.size(); }

  /// Returns the next char without consuming it.
  /// If the string is completly consumed, it returns a nullptr.
  const char *peek();

  /// Reads the next char, consuming it.
  /// If the string is completly consumed, it returns a nullptr.
  const char *read();
};
} // namespace tokenizer
} // namespace basic_sql
#endif