#ifndef _SMALL_STRING_H_
#define _SMALL_STRING_H_
template <size_t N> class SmallString {
public:
  /// Make an empty SmallString
  SmallString() : m_len(0) {}
  /// Copy constructor
  SmallString(const SmallString &other) : m_len(other.m_len) {
    for (size_t i = 0; i < other.m_len; i++)
      this->m_data[i] = other.m_data[i];
  }
  /// Make a small string copying from ptr up to len or N, whichever is smaller
  SmallString(const char *ptr, size_t len) : m_len(N < len ? N : len) {
    for (size_t i = 0; i < m_len; i++)
      this->m_data[i] = ptr[i];
  }

  /// Get a ptr to the data.
  const char *get_ptr() const { return m_data; }

  /// Get the size
  size_t size() const { return m_len; }

  /// Append data. Returns false if the data was not written.
  bool append(const char *data, size_t len) {
    if (this->m_len + len >= N)
      return false;
    for (size_t i = 0; i < len; i++) {
      this->m_data[this->m_len + i] = data[i];
    }
    this->m_len += len;

    return true;
  }

  /// Append a char. Returns false if the data was not written.
  bool push(char data) {
    if (1 + this->m_len >= N)
      return false;
    this->m_data[this->m_len] = data;
    this->m_len++;
    return true;
  }

  void clear() { m_len = 0; }

  /// Index the slice.
  /// i must not be greater than the length.
  const char &operator[](size_t i) const {
    assert(i < this->m_len);
    return this->m_data[i];
  }

protected:
private:
  char m_data[N];
  size_t m_len;
};

template <size_t N>
std::ostream &operator<<(std::ostream &os, const SmallString<N> &s) {
  for (size_t i = 0; i < s.size(); i++)
    os << s[i];
  return os;
}

template <size_t N>
bool operator==(const SmallString<N> &lhs, const SmallString<N> &rhs) {
  size_t lhs_size = lhs.size();
  if (lhs_size != rhs.size())
    return false;

  for (size_t i = 0; i < lhs_size; i++)
    if (lhs[i] != rhs[i])
      return false;

  return true;
}
#endif