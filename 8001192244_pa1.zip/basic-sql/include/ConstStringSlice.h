#ifndef _CONST_STRING_SLICE_
#define _CONST_STRING_SLICE_

#include <cassert>
#include <cstddef>
#include <cstring>
#include <ostream>

namespace basic_sql {
class ConstStringSlice {
public:
  /// Make an empty ConstStringSlice.
  ConstStringSlice();

  /// Make a ConstStringSlice from a c string.
  ConstStringSlice(const char *c_str);

  /// Make a ConstStringSlice reference from parts.
  ConstStringSlice(const char *ptr, size_t len);

  /// Returns true if this is empty.
  bool is_empty() const;

  /// Return the number of chars.
  size_t size() const;

  // TODO: Accept slice instead
  // TODO: rename to equals_case_insensitive?
  /// Compare this slice with a c string, ignoring case.
  /// Returns true if they are equal.
  bool case_insensitive_compare(const char *other) const;

  /// See if this slice starts with another
  bool starts_with(ConstStringSlice slice);

  /// Index the slice.
  /// i must not be greater than the length.
  const char &operator[](size_t i) const;

protected:
private:
  const char *ptr;
  size_t len;
};

std::ostream &operator<<(std::ostream &os, const ConstStringSlice &t);

bool operator==(const ConstStringSlice &lhs, const ConstStringSlice &rhs);
} // namespace basic_sql
#endif