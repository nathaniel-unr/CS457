#ifndef _BASIC_SQL_H_
#define _BASIC_SQL_H_
#include "ConstStringSlice.h"
#include "SmallString.h"
#include "SqlTokenizer.h"

namespace basic_sql {
using tokenizer::SqlToken;
using tokenizer::SqlTokenizer;
using tokenizer::SqlTokenizerError;
} // namespace basic_sql

const size_t DATABASE_MAX_NAME_SIZE = 16;
const size_t TABLE_NAME_MAX_LENGTH = 16;
const size_t COLUMN_NAME_MAX_LENGTH = 16;
const size_t COLUMN_MAX = 16;

struct SqlStatementCreateDatabase {
  SmallString<DATABASE_MAX_NAME_SIZE> database_name;
};

struct SqlStatementDropDatabase {
  SmallString<DATABASE_MAX_NAME_SIZE> database_name;
};

struct SqlStatementUseDatabase {
  SmallString<DATABASE_MAX_NAME_SIZE> database_name;
};

enum class SqlStatementType {
  CREATE_DATABASE,
  DROP_DATABASE,
  USE_DATABASE,
  CREATE_TABLE,
  DROP_TABLE,
  SELECT,
  ALTER
};
#endif