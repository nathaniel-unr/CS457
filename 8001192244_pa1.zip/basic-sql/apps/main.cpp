#include "BasicSql.h"
#include <cassert>
#include <cctype>
#include <iostream>
#include <stdio.h>
#include <string>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>

template <size_t N, typename T> class SmallVec {
public:
  SmallVec() : m_len(0) {}
  bool push(T data) {
    if (m_len >= N)
      return false;
    this->m_data[m_len] = data;
    this->m_len++;
    return true;
  }

  size_t size() { return m_len; }

  /// Index the slice.
  /// i must not be greater than the length.
  const T &operator[](size_t i) const {
    assert(i < this->m_len);
    return this->m_data[i];
  }

private:
  T m_data[N];
  size_t m_len;
};

struct SqlType {
  basic_sql::tokenizer::SqlType type;
  // Should be set to 1 if not variable, but this is optional for now.
  size_t size;
};

struct SqlColumn {
  SmallString<COLUMN_NAME_MAX_LENGTH> name;
  SqlType type;
};

struct SqlStatementCreateTable {
  SmallString<TABLE_NAME_MAX_LENGTH> table_name;
  SmallVec<COLUMN_MAX, SqlColumn> columns;
};

struct SqlStatementDropTable {
  SmallString<TABLE_NAME_MAX_LENGTH> table_name;
};

struct SqlStatementSelect {
  SmallString<TABLE_NAME_MAX_LENGTH> table_name;
};

struct SqlStatementAlter {
  SmallString<TABLE_NAME_MAX_LENGTH> table_name;
};

class SqlStatement {
public:
  SqlStatement(SqlStatementCreateDatabase create_database)
      : m_statement_type(SqlStatementType::CREATE_DATABASE),
        m_create_database(create_database) {}
  SqlStatement(SqlStatementDropDatabase drop_database)
      : m_statement_type(SqlStatementType::DROP_DATABASE),
        m_drop_database(drop_database) {}
  SqlStatement(SqlStatementUseDatabase use_database)
      : m_statement_type(SqlStatementType::USE_DATABASE),
        m_use_database(use_database) {}
  SqlStatement(SqlStatementCreateTable create_table)
      : m_statement_type(SqlStatementType::CREATE_TABLE),
        m_create_table(create_table) {}
  SqlStatement(SqlStatementDropTable drop_table)
      : m_statement_type(SqlStatementType::DROP_TABLE),
        m_drop_table(drop_table) {}
  SqlStatement(SqlStatementSelect select)
      : m_statement_type(SqlStatementType::SELECT), m_select(select) {}
  SqlStatement(SqlStatementAlter alter)
      : m_statement_type(SqlStatementType::ALTER), m_alter(alter) {}
  SqlStatement(const SqlStatement &other) {
    this->m_statement_type = other.m_statement_type;
    switch (m_statement_type) {
    case SqlStatementType::CREATE_DATABASE:
      this->m_create_database = other.m_create_database;
      break;
    case SqlStatementType::DROP_DATABASE:
      this->m_drop_database = other.m_drop_database;
      break;
    case SqlStatementType::USE_DATABASE:
      this->m_use_database = other.m_use_database;
      break;
    case SqlStatementType::CREATE_TABLE:
      this->m_create_table = other.m_create_table;
      break;
    case SqlStatementType::DROP_TABLE:
      this->m_drop_table = other.m_drop_table;
      break;
    case SqlStatementType::SELECT:
      this->m_select = other.m_select;
      break;
    case SqlStatementType::ALTER:
      this->m_alter = other.m_alter;
      break;
    }
  }

  /// Get the statement type
  SqlStatementType statement_type() { return this->m_statement_type; }

  SqlStatementCreateDatabase &create_database() {
    assert(this->m_statement_type == SqlStatementType::CREATE_DATABASE);
    return this->m_create_database;
  }

  SqlStatementDropDatabase &drop_database() {
    assert(this->m_statement_type == SqlStatementType::DROP_DATABASE);
    return this->m_drop_database;
  }

  SqlStatementUseDatabase &use_database() {
    assert(this->m_statement_type == SqlStatementType::USE_DATABASE);
    return this->m_use_database;
  }

  SqlStatementCreateTable &create_table() {
    assert(this->m_statement_type == SqlStatementType::CREATE_TABLE);
    return this->m_create_table;
  }

  SqlStatementDropTable &drop_table() {
    assert(this->m_statement_type == SqlStatementType::DROP_TABLE);
    return this->m_drop_table;
  }

  SqlStatementSelect &select() {
    assert(this->m_statement_type == SqlStatementType::SELECT);
    return this->m_select;
  }

  SqlStatementAlter &alter() {
    assert(this->m_statement_type == SqlStatementType::ALTER);
    return this->m_alter;
  }

protected:
private:
  SqlStatementType m_statement_type;
  union {
    SqlStatementCreateDatabase m_create_database;
    SqlStatementDropDatabase m_drop_database;
    SqlStatementUseDatabase m_use_database;
    SqlStatementCreateTable m_create_table;
    SqlStatementDropTable m_drop_table;
    SqlStatementSelect m_select;
    SqlStatementAlter m_alter;
  };
};

enum class SqlParserErrorType {
  OK,
  LEXER,
};

class SqlParserError {
public:
  SqlParserError() : m_error_type(SqlParserErrorType::OK) {}

  /// Check if this error is ok
  bool is_ok() { return this->m_error_type == SqlParserErrorType::OK; }

protected:
private:
  SqlParserErrorType m_error_type;
};

class SqlParser {
public:
  // TODO: maybe juts proivde the token buffer, and a utility func to tokenize
  // the string and feed it
  // TODO: Consider parser reuse
  SqlParser(const std::string &input) : tokenizer(input), position(0) {}

  SqlParserError parse_all(std::vector<SqlStatement> &statements) {
    // TODO: If error, reject/return
    basic_sql::SqlTokenizerError tokenizer_error =
        this->tokenizer.tokenize(this->tokens);

    SqlParserError parser_error;

    while (this->peek() != nullptr) {
      this->parse_statement(statements, parser_error);
      if (!parser_error.is_ok())
        return parser_error;
    }

    return parser_error;
  }

  void parse_statement(std::vector<SqlStatement> &statements,
                       SqlParserError &error) {
    const basic_sql::SqlToken *token = this->read();
    // TODO: Error
    assert(token != nullptr);

    switch (token->token_type()) {
    case basic_sql::tokenizer::SqlTokenType::KEYWORD:
      switch (token->keyword()) {
      case basic_sql::tokenizer::SqlKeyword::CREATE:
        basic_sql::tokenizer::SqlKeyword keyword;
        // TODO: Propogate error
        this->read_keyword(&keyword);

        switch (keyword) {
        case basic_sql::tokenizer::SqlKeyword::DATABASE: {
          // CREATE DATABASE <identifier>;
          basic_sql::tokenizer::SqlIdentifier identifier;
          // TODO: Propogate error
          this->read_identifier(&identifier);
          // TODO: Propogate error
          this->read_semicolon();

          SqlStatementCreateDatabase create_database_statement{
            database_name : SmallString<DATABASE_MAX_NAME_SIZE>(
                &identifier.slice[0], identifier.slice.size())
          };
          SqlStatement statement(create_database_statement);
          statements.push_back(statement);
          break;
        }

        case basic_sql::tokenizer::SqlKeyword::TABLE: {
          // CREATE TABLE <identifier> (a1 int, a2 varchar(20));
          basic_sql::tokenizer::SqlIdentifier identifier;
          // TODO: Propogate error
          this->read_identifier(&identifier);
          // TODO: Propogate error
          this->read_left_parenthesis();

          SmallVec<COLUMN_MAX, SqlColumn> columns;

          // Ensure 1 col
          {
            basic_sql::tokenizer::SqlIdentifier column_identifier;
            // TODO: Propogate error
            this->read_identifier(&column_identifier);
            SqlType type;
            // TODO: Propogate error
            this->read_type(&type);

            SmallString<COLUMN_NAME_MAX_LENGTH> name(
                &column_identifier.slice[0], column_identifier.slice.size());
            columns.push(SqlColumn{
              name : name,
              type : type,
            });
          }

          const basic_sql::SqlToken *token = this->peek();
          while (token != nullptr &&
                 token->token_type() !=
                     basic_sql::tokenizer::SqlTokenType::RIGHT_PARENTHESIS) {
            // TODO: Validate  comma
            this->read();

            basic_sql::tokenizer::SqlIdentifier column_identifier;
            // TODO: Propogate error
            this->read_identifier(&column_identifier);
            SqlType type;
            // TODO: Propogate error
            this->read_type(&type);

            SmallString<COLUMN_NAME_MAX_LENGTH> name(
                &column_identifier.slice[0], column_identifier.slice.size());
            columns.push(SqlColumn{
              name : name,
              type : type,
            });

            token = this->peek();
          }

          // TODO: Propogate error
          assert(columns.size() > 0);

          // TODO: Propogate error
          this->read_right_parenthesis();
          // TODO: Propogate error
          this->read_semicolon();

          SmallString<TABLE_NAME_MAX_LENGTH> name(&identifier.slice[0],
                                                  identifier.slice.size());
          statements.push_back(
              SqlStatement(SqlStatementCreateTable{name, columns}));

          break;
        }

        default:
          std::cout << "UNEXPECTED KEYWORD IN CREATE: " << keyword << std::endl;
          abort();
        }

        break;
      case basic_sql::tokenizer::SqlKeyword::DROP: {
        basic_sql::tokenizer::SqlKeyword keyword;
        // TODO: Propogate error
        this->read_keyword(&keyword);

        switch (keyword) {
        case basic_sql::tokenizer::SqlKeyword::DATABASE: {
          // DROP DATABASE <identifier>;
          basic_sql::tokenizer::SqlIdentifier identifier;
          // TODO: Propogate error
          this->read_identifier(&identifier);
          // TODO: Propogate error
          this->read_semicolon();

          SqlStatementDropDatabase drop_database_statement{
            database_name : SmallString<DATABASE_MAX_NAME_SIZE>(
                &identifier.slice[0], identifier.slice.size())
          };
          SqlStatement statement(drop_database_statement);
          statements.push_back(statement);
          break;
        }
        case basic_sql::tokenizer::SqlKeyword::TABLE: {
          // DROP TABLE <identifier>;
          basic_sql::tokenizer::SqlIdentifier identifier;
          // TODO: Propogate error
          this->read_identifier(&identifier);
          // TODO: Propogate error
          this->read_semicolon();

          SqlStatementDropTable drop_table_statement{
            table_name : SmallString<TABLE_NAME_MAX_LENGTH>(
                &identifier.slice[0], identifier.slice.size())
          };
          SqlStatement statement(drop_table_statement);
          statements.push_back(statement);
          break;
        }
        default:
          std::cout << "UNEXPECTED KEYWORD IN DROP: " << keyword << std::endl;
          abort();
        }
        break;
      }
      case basic_sql::tokenizer::SqlKeyword::USE: {
        // USE <identifier>;
        basic_sql::tokenizer::SqlIdentifier identifier;
        // TODO: Propogate error
        this->read_identifier(&identifier);
        // TODO: Propogate error
        this->read_semicolon();
        SqlStatementUseDatabase use_database_statement{
          database_name : SmallString<DATABASE_MAX_NAME_SIZE>(
              &identifier.slice[0], identifier.slice.size())
        };
        SqlStatement statement(use_database_statement);
        statements.push_back(statement);
        break;
      }
      case basic_sql::tokenizer::SqlKeyword::SELECT: {
        // TODO: Parse cols
        while (this->peek()->token_type() !=
               basic_sql::tokenizer::SqlTokenType::KEYWORD) {
          this->read();
        }
        this->read();

        basic_sql::tokenizer::SqlIdentifier identifier;
        this->read_identifier(&identifier);
        this->read_semicolon();
        SqlStatementSelect select{
          table_name : SmallString<TABLE_NAME_MAX_LENGTH>(
              &identifier.slice[0], identifier.slice.size()),
        };
        statements.push_back(SqlStatement(select));
        break;
      }
      case basic_sql::tokenizer::SqlKeyword::ALTER: {
        this->read();
        basic_sql::tokenizer::SqlIdentifier identifier;
        this->read_identifier(&identifier);

        while (this->peek()->token_type() !=
               basic_sql::tokenizer::SqlTokenType::SEMICOLON) {
          this->read();
        }
        this->read();

        SqlStatementAlter alter{
          table_name : SmallString<TABLE_NAME_MAX_LENGTH>(
              &identifier.slice[0], identifier.slice.size()),
        };
        statements.push_back(SqlStatement(alter));

        break;
      }
      default:
        // TODO: return err
        std::cout << "UNEXPECTED KEYWORD TOKEN: " << *token << std::endl;
        abort();
      }
      break;
    default:
      // TODO: return err
      std::cout << "UNEXPECTED TOKEN: " << *token << std::endl;
      abort();
    };
  }

protected:
private:
  basic_sql::SqlTokenizer tokenizer;
  size_t position;
  std::vector<basic_sql::SqlToken> tokens;

  // TODO: Dynamically tokenize here instead of doing it upfront
  /// Peek the next token, return nullptr if there is none.
  const basic_sql::SqlToken *peek() {
    if (position >= tokens.size())
      return nullptr;
    return &tokens[this->position];
  }

  /// Read the next token, marking it as read.
  const basic_sql::SqlToken *read() {
    const basic_sql::SqlToken *token = this->peek();
    if (token != nullptr)
      position += 1;
    return token;
  }

  /// Read the next keyword, marking it as read.
  SqlParserError read_keyword(basic_sql::tokenizer::SqlKeyword *keyword) {
    const basic_sql::SqlToken *token = this->read();
    // TODO: Return error
    assert(token != nullptr);
    if (token->token_type() != basic_sql::tokenizer::SqlTokenType::KEYWORD) {
      // TODO: return error
      std::cout << "EXPECTED KEYWORD" << std::endl;
      abort();
    }

    *keyword = token->keyword();

    return SqlParserError{};
  }

  /// Read the next identifier, marking it as read.
  SqlParserError
  read_identifier(basic_sql::tokenizer::SqlIdentifier *identifier) {
    const basic_sql::SqlToken *token = this->read();
    // TODO: Return error
    assert(token != nullptr);
    if (token->token_type() != basic_sql::tokenizer::SqlTokenType::IDENTIFIER) {
      // TODO: return error
      std::cout << "EXPECTED IDENTIFIER: " << token->token_type() << std::endl;
      abort();
    }

    *identifier = token->identifier();

    return SqlParserError{};
  }

  /// Read the next keyword, marking it as read.
  SqlParserError read_semicolon() {
    const basic_sql::SqlToken *token = this->read();
    // TODO: Return error
    assert(token != nullptr);
    if (token->token_type() != basic_sql::tokenizer::SqlTokenType::SEMICOLON) {
      // TODO: return error
      std::cout << "EXPECTED SEMICOLON, GOT: " << token->token_type()
                << std::endl;
      abort();
    }

    return SqlParserError{};
  }

  /// Read the next keyword, marking it as read.
  SqlParserError read_left_parenthesis() {
    const basic_sql::SqlToken *token = this->read();
    // TODO: Return error
    assert(token != nullptr);
    if (token->token_type() !=
        basic_sql::tokenizer::SqlTokenType::LEFT_PARENTHESIS) {
      // TODO: return error
      std::cout << "EXPECTED LEFT PARENTHESIS" << std::endl;
      abort();
    }

    return SqlParserError{};
  }

  /// Read the next keyword, marking it as read.
  SqlParserError read_right_parenthesis() {
    const basic_sql::SqlToken *token = this->read();
    // TODO: Return error
    assert(token != nullptr);
    if (token->token_type() !=
        basic_sql::tokenizer::SqlTokenType::RIGHT_PARENTHESIS) {
      // TODO: return error
      std::cout << "EXPECTED RIGHT PARENTHESIS" << std::endl;
      abort();
    }

    return SqlParserError{};
  }

  /// Read the next integer, marking it as read.
  SqlParserError read_integer(basic_sql::tokenizer::SqlInteger *integer) {
    const basic_sql::SqlToken *token = this->read();
    // TODO: Return error
    assert(token != nullptr);
    if (token->token_type() != basic_sql::tokenizer::SqlTokenType::INTEGER) {
      // TODO: return error
      std::cout << "EXPECTED INTEGER: " << token->token_type() << std::endl;
      abort();
    }

    *integer = token->integer();

    return SqlParserError{};
  }

  /// Read the next type, marking it as read.
  SqlParserError read_type(SqlType *type) {
    const basic_sql::SqlToken *token = this->read();
    // TODO: Return error
    assert(token != nullptr);
    if (token->token_type() != basic_sql::tokenizer::SqlTokenType::TYPE) {
      // TODO: return error
      std::cout << "EXPECTED TYPE: " << token->token_type() << std::endl;
      abort();
    }

    size_t size = 1;
    if (token->type() == basic_sql::tokenizer::SqlType::VARCHAR ||
        token->type() == basic_sql::tokenizer::SqlType::CHAR) {
      // TODO: Return error
      this->read_left_parenthesis();
      // TODO: Return error
      basic_sql::tokenizer::SqlInteger integer;
      this->read_integer(&integer);
      size = integer.number;
      // TODO: Return error
      this->read_right_parenthesis();
    }

    *type = SqlType{
      type : token->type(),
      size,
    };

    return SqlParserError{};
  }
};

class SqlError {};

// TODO: error handling
class SqlDatabase {
public:
  SqlDatabase() : m_index(nullptr) {}
  SqlDatabase(SqlDatabase &other) = delete;
  SqlDatabase &operator=(const SqlDatabase &other) = delete;
  SqlDatabase(SqlDatabase &&other) noexcept {
    this->m_name = other.m_name;
    this->m_index = other.m_index;

    // m_name was copied, not moved.
    other.m_index = nullptr;
  }
  SqlDatabase &operator=(SqlDatabase &&other) {
    this->close();
    this->m_name = other.m_name;
    this->m_index = other.m_index;

    // m_name was copied, not moved.
    other.m_index = nullptr;

    return *this;
  }

  void open(SmallString<DATABASE_MAX_NAME_SIZE> &name, SqlError *error) {
    // TODO: Error
    assert(m_index == nullptr);
    m_name.clear();

    // Allocate dbname + NUL
    SmallString<DATABASE_MAX_NAME_SIZE + 1> index_dir_name;
    index_dir_name.append(name.get_ptr(), name.size());
    index_dir_name.push(0);

    // TODO: Error check
    struct stat st = {0};
    assert(stat(index_dir_name.get_ptr(), &st) == -1);
    mkdir(index_dir_name.get_ptr(), 0700);

    // Allocate dbname + "/" + dbname + ".db-index", which is 9 + 1 + NUL, which
    // is 11 db names with NULs in them are considered logic errors right now.
    // They may be explicity rejected in the future.
    SmallString<DATABASE_MAX_NAME_SIZE + 11> index_file_name;
    index_file_name.append(name.get_ptr(), name.size());
    index_file_name.push('/');
    index_file_name.append(name.get_ptr(), name.size());
    index_file_name.append(".db-index", 9);
    index_file_name.push(0);

    // TODO: Open existing support
    const char *flags = "wb+";
    FILE *index = fopen(index_file_name.get_ptr(), flags);
    assert(index != nullptr);

    this->m_name.append(name.get_ptr(), name.size());
    this->m_index = index;

    // Setup
    // TODO: Error handling
    fwrite("index-db", 1, 8, this->m_index);
  }

  void remove_database() {
    // TODO: Errors
    this->close();

    // Allocate dbname + "/" + dbname + ".db-index", which is 9 + 1 + NUL, which
    // is 11 db names with NULs in them are considered logic errors right now.
    // They may be explicity rejected in the future.
    SmallString<DATABASE_MAX_NAME_SIZE + 11> index_file_name;
    index_file_name.append(m_name.get_ptr(), m_name.size());
    index_file_name.push('/');
    index_file_name.append(m_name.get_ptr(), m_name.size());
    index_file_name.append(".db-index", 9);
    index_file_name.push(0);

    assert(remove(index_file_name.get_ptr()) == 0);

    // Allocate dbname + NUL
    SmallString<DATABASE_MAX_NAME_SIZE + 1> index_dir_name;
    index_dir_name.append(m_name.get_ptr(), m_name.size());
    index_dir_name.push(0);

    std::cout << "Deleted " << index_dir_name << std::endl;

    assert(rmdir(index_dir_name.get_ptr()) == 0);
  }

  void close() {
    // TODO: Return errors
    if (m_index != nullptr) {
      fclose(m_index);
      m_index = nullptr;
    }
  }

  ~SqlDatabase() { this->close(); }

  const SmallString<DATABASE_MAX_NAME_SIZE> &name() const { return m_name; }

protected:
private:
  SmallString<DATABASE_MAX_NAME_SIZE> m_name;
  FILE *m_index;
};

size_t search_db_by_name(const std::vector<SqlDatabase> &databases,
                         const SmallString<DATABASE_MAX_NAME_SIZE> &name) {
  size_t database_index = -1;
  for (size_t i = 0; i < databases.size(); i++) {
    if (databases[i].name() == name) {
      database_index = i;
      break;
    }
  }
  return database_index;
}

int main() {
  // TODO: Encapsulate in DB Manager Class
  // TODO: make hashmap? this has a low # of dbs usually?
  std::vector<SqlDatabase> databases;
  SmallString<DATABASE_MAX_NAME_SIZE> current_database_name;

  bool should_exit = false;
  std::string string_input;
  while (!should_exit) {
    string_input.clear();
    // TODO: handle errors?
    std::getline(std::cin, string_input);

    // TODO: Convert to string slice immediately, use for tokenizer
    // TODO: Add impl for from std::string construction
    basic_sql::ConstStringSlice string_input_slice(string_input.c_str(),
                                                   string_input.size());

    if (string_input_slice.case_insensitive_compare(".EXIT")) {
      should_exit = true;
      std::cout << "All done." << std::endl;
    } else if (string_input_slice.starts_with("--")) {
      // TODO: Lex and parse this instead of ignoring
      // ignore line
    } else {
      SqlParser parser(string_input);
      std::vector<SqlStatement> statements;
      SqlParserError parser_error = parser.parse_all(statements);

      for (size_t i = 0; i < statements.size(); i++) {
        switch (statements[i].statement_type()) {
        case SqlStatementType::CREATE_DATABASE: {
          SqlStatementCreateDatabase statement =
              statements[i].create_database();

          size_t database_index =
              search_db_by_name(databases, statement.database_name);
          if (database_index != -1) {
            std::cout << "!Failed to create database "
                      << statement.database_name
                      << " because it already exists." << std::endl;
          } else {
            SqlDatabase database;
            SqlError sql_error;
            database.open(statement.database_name, &sql_error);
            databases.push_back(std::move(database));
            std::cout << "Database " << statement.database_name << " created."
                      << std::endl;
          }
          break;
        }
        case SqlStatementType::DROP_DATABASE: {
          SqlStatementDropDatabase statement = statements[i].drop_database();
          size_t database_index =
              search_db_by_name(databases, statement.database_name);

          if (database_index == -1) {
            std::cout << "!Failed to delete " << statement.database_name
                      << " because it does not exist." << std::endl;
          } else {
            databases[database_index].remove_database();
            databases.erase(databases.begin() + database_index);
            std::cout << "Database " << statement.database_name << " deleted."
                      << std::endl;
          }
          break;
        }
        case SqlStatementType::USE_DATABASE: {
          SqlStatementUseDatabase statement = statements[i].use_database();
          size_t database_index =
              search_db_by_name(databases, statement.database_name);
          if (database_index == -1) {
            std::cout << "Database does noo exist" << std::endl;
          } else {
            current_database_name = statement.database_name;
            std::cout << "Using database " << statement.database_name << "."
                      << std::endl;
          }
          break;
        }
        case SqlStatementType::CREATE_TABLE: {
          SqlStatementCreateTable statement = statements[i].create_table();
          // TODO: Add functionality
          std::cout << "Table " << statement.table_name << " created."
                    << std::endl;
          for (size_t i = 0; i < statement.columns.size(); i++) {
            std::cout << statement.columns[i].name;

            // TODO: Make function
            switch (statement.columns[i].type.type) {
            case basic_sql::tokenizer::SqlType::INT:
              std::cout << " int";
              break;
            case basic_sql::tokenizer::SqlType::VARCHAR:
              std::cout << " varchar(" << statement.columns[i].type.size << ")";
              break;
            case basic_sql::tokenizer::SqlType::CHAR:
              std::cout << " char(" << statement.columns[i].type.size << ")";
            }

            if (i + 1 < statement.columns.size()) {
              std::cout << " | ";
            }
          }
          std::cout << std::endl;
          break;
        }
        case SqlStatementType::DROP_TABLE: {
          // TODO: Drop table
          SqlStatementDropTable statement = statements[i].drop_table();
          break;
        }
        case SqlStatementType::SELECT: {
          SqlStatementSelect statement = statements[i].select();
          // TODO: SELECT
          break;
        }
        case SqlStatementType::ALTER: {
            // TODO: Add functionality
          SqlStatementAlter statement = statements[i].alter();
          std::cout << "Table "<< statement.table_name << " modified." << std::endl;
          break;
        }
        default:
          std::cout << "Unknown statement type" << std::endl;
        }
      }
    }
  }

  return 0;
}